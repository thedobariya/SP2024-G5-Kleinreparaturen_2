#include <stdio.h>
#include <stdint.h>

// Function to print the binary representation of a float number
void floatToBinary(float num) {
    // Treat the memory of the float as an unsigned 32-bit integer
    uint32_t* ptr = (uint32_t*)&num;

    // Mask for extracting each bit
    uint32_t mask = 1u << 31;
   
    printf("Binary representation of %f: \n", num);
    printf("\n");
    printf("Im Speicher steht\n");
    // Iterate through each bit and print it
    for (int i = 0; i < 32; i++) {
        printf("%d", (*ptr & mask) ? 1 : 0);
        if ((i + 1) % 8 == 0) printf(" "); // For readability, separate bytes
        *ptr <<= 1; // Shift to the next bit
    }

    printf("\n\n\n");

}

int main() {
    float num;

    // Read float number from user input
    printf("Enter a float number: ");
    scanf("%f", &num);

    // Call the function to print its binary representation
    floatToBinary(num);

    return 0;
}
