#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

int global1;
int global2;

int address_difference(void *ptr1, void *ptr2) {
    return abs((int)ptr1 - (int)ptr2);
}

int main() {
    int a1, b1;
    short a2, b2;
    char a3, b3;

    int *dynamic1 = (int *)malloc(sizeof(int));
    int *dynamic2 = (int *)malloc(sizeof(int));


    printf("Adressen der lokalen Variablen:\n");
    printf("a1: %p\n", (void*)&a1);
    printf("b1: %p\n", (void*)&b1);
    printf("a2: %p\n", (void*)&a2);
    printf("b2: %p\n", (void*)&b2);
    printf("a3: %p\n", (void*)&a3);
    printf("b3: %p\n", (void*)&b3);

    printf("\nAdressen der globalen Variablen:\n");
    printf("global1: %p\n", (void*)&global1);
    printf("global2: %p\n", (void*)&global2);

    // Adressen der dynamischen Variablen
    printf("\nAdressen der dynamischen Variablen:\n");
    printf("dynamic1: %p\n", (void*)dynamic1);
    printf("dynamic2: %p\n", (void*)dynamic2);

    printf("\nAbstand der Adressen:\n");
    printf("Differenz zwischen a1 und b1: %lu Bytes\n", (unsigned long)(&b1 - &a1));
    printf("Differenz zwischen a2 und b2: %lu Bytes\n", (unsigned long)(&b2 - &a2));
    printf("Differenz zwischen a3 und b3: %lu Bytes\n", (unsigned long)(&b3 - &a3));
    printf("Differenz zwischen dynamic1 und dynamic2: %lu Bytes\n", (unsigned long)(dynamic2 - dynamic1));

    free(dynamic1);
    free(dynamic2);

    // Variablen mit register-Speichermodifizierer
    register int reg_var1 = 10;
    register int reg_var2 = 20;

    // Variablen mit static-Speichermodifizierer
    static int static_var1 = 30;
    static int static_var2 = 40;

    // Adressen der Variablen mit register-Speichermodifizierer
    printf("\nAdressen der Variablen mit register-Speichermodifizierer:\n");
    // printf("reg_var1: %p\n", (void*)&reg_var1);
    // printf("reg_var2: %p\n", (void*)&reg_var2);

    // Adressen der Variablen mit static-Speichermodifizierer
    printf("\nAdressen der Variablen mit static-Speichermodifizierer:\n");
    printf("static_var1: %p\n", (void*)&static_var1);
    printf("static_var2: %p\n", (void*)&static_var2);


    // Statisches Array mit 5 int-Elementen
    int static_array[5];

    // Dynamisch allokierte Variable für 5 Integer
    int *dynamic_array = (int *)malloc(5 * sizeof(int));
    
    // Adresse des statischen Arrays
    printf("\nAdresse des statischen Arrays:\n");
    printf("static_array: %p\n", (void*)static_array);

    // Adresse der dynamisch allokierten Variable
    printf("\nAdresse der dynamisch allokierten Variable:\n");
    printf("dynamic_array: %p\n", (void*)dynamic_array);

    // Freigabe des dynamisch allokierten Speichers
    free(dynamic_array);

    // Unterschiede zwischen den Speicherbereichen von statischem Array und dynamischer Variable berechnen
    int diff_static_dynamic = address_difference(static_array, dynamic_array);
    printf("Differenz der Adressen zwischen statischem Array und dynamischer Variable: %d Bytes\n", diff_static_dynamic);





    return 0;
}

